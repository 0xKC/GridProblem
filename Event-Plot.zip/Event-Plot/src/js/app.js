//Constants
var MIN_AXIS = -10;
var MAX_AXIS = 10;
var MAX_POINTS = 441;

var colors = ['#0D47A1', '#E65100', '#827717', '#004D40', '#4A148C'];

//function to generate random events and plot on map
function generateRandomEvents(max_events) {
    var events = {};
    for (var i = 0; i < max_events; i++) {

        var coordinates = getCoordinates();

        if (!events[coordinates.x]) {
            events[coordinates.x] = {};
        }

        events[coordinates.x][coordinates.y] = {
            id: getUID(),
            details: generateTicket()
        };
    }

    return events;
}
//function to generate random coordinates to plot 
function getCoordinates() {
    return {
        x: generateRandomNumber(MIN_AXIS, MAX_AXIS),
        y: generateRandomNumber(MIN_AXIS, MAX_AXIS)
    }
}
//function to generate tickets
function generateTicket() {
    var totalTickets = generateRandomNumber(0, 1000);
    var tickets = [];
    var low = 100;
    for (var i = 0; i < totalTickets; i++) {
        var price = generateRandomDecimalNumber(1, 100);
        tickets.push({
            price: price
        });

        if (price < low) {
            low = price;
        }
    }
    return {tickets: tickets, lowestPrice: low};
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateRandomDecimalNumber(min, max) {
    return (Math.random() * (max - min) + min).toFixed(3);
}

function getUID() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }

    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}

function getRandomColor() {
    var min = 0;
    var max = colors.length - 1;
    return colors[Math.floor(Math.random() * (max - min + 1)) + min];
}
//function to display ticket price when mouse is hovered over a coordinate
function getHTMLTemplate(event, x, y) {
    if (event) {
        return '<div class="point has-event" x="' + x + '" y="' + y + '" style="background-color:' + getRandomColor() + '">' +
            '<div class="hover-details">' +
            'Co-Ordinates : (' + x + ',' + y + ') <br/>' +
            'Number of tickets: ' + event.details.tickets.length + '<br/>' +
            'Starting price from $' + event.details.lowestPrice + '<br/>' +
            '</div>' +
            '</div>';
    } else {
        return '<div class="point" x="' + x + '" y="' + y + '"></div>';
    }
}
//function to plot the graph 
function plotGraph(events, parentElement) {
    for (var x = 10; x >= -10; x--) {
        var rowElement = document.createElement('div');
        $(rowElement).addClass("row-" + x)
            .appendTo(parentElement);
        rowElement = $(rowElement);
        for (var y = -10; y <= 10; y++) {
            if (events[x] && events[x][y]) {
                rowElement.append(getHTMLTemplate(events[x][y], x, y));
            } else {
                rowElement.append(getHTMLTemplate(null, x, y));
            }
        }
    }
}
//regex for search box
var searchRegex = /\s*(-*[0-9]+)\s*,\s*(-*[0-9]+)\s*/g;

var totalEvents = generateRandomNumber(0, MAX_POINTS);
var events = generateRandomEvents(totalEvents);
plotGraph(events, $(".graph-container"));

$(".has-event").click(function (event) {
    var x = parseInt($(this).attr("x"));
    var y = parseInt($(this).attr("y"));
    disableAll();
    selectNeighbourNodes(x, y);
    event.stopPropagation();
});

$(".has-event").mouseenter(function (event) {
    $(this).find(".hover-details").css("visibility", "visible");
});

$(".has-event").mouseleave(function (event) {
    $(this).find(".hover-details").css("visibility", "hidden");
});

$(window).click(function () {
    resetAll();
});

$('.search-input').on('input', function () {
    var inputString = $(this).val();

    if (!inputString || inputString.trim().length < 0) {
        resetAll();
    }

    var matches;
    while (matches = searchRegex.exec(inputString)) {
        var x = parseInt(matches[1]);
        var y = parseInt(matches[2]);

        disableAll();
        selectNeighbourNodes(x, y);
    }
});

function resetAll() {
    $('.has-event').each(function () {
        $(this).removeClass('disable');
        $(this).removeClass('selected');
    });
    $(".m-distance").remove();
}

function disableAll() {
    $('.has-event').each(function () {
        $(this).addClass('disable');
        $(this).removeClass('selected');
    });
    $(".m-distance").remove();
}
//function to get nearby events
function selectNeighbourNodes(x, y) {
    $('.has-event[x="' + x + '"][y="' + y + '"]').addClass('selected');
    for (var x1 = -1; x1 <= 1; x1++) {
        for (var y1 = -1; y1 <= 1; y1++) {
            var nX = x1 + x;
            var nY = y1 + y;
            $('.has-event[x="' + nX + '"][y="' + nY + '"]').removeClass('disable');

            if (nX !== x || nY !== y)
                $('.has-event[x="' + nX + '"][y="' + nY + '"]').find('.hover-details').append('<div class="m-distance">Distance: ' + manhattanDistance(x, y, nX, nY) + '</div>');
        }
    }
}
//function to calculate manhattan distance
function manhattanDistance(x0, y0, x1, y1) {
    return Math.abs(x1 - x0) + Math.abs(y1 - y0);
}